<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HintAPI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</head>
<body>
  
<div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">GET Request</h5>
                <form id="getRequestForm" action="/get" method="get">
                    <div class="form-group">
                        <label for="getUserId">User ID:</label>
                        <input type="number" class="form-control" id="getUserId" name="getUserId">
                    </div>
                    <button type="submit" class="btn btn-primary">Get User</button>
                </form>
                <?php if ($type == 'get'): ?>
         <div id="getResponse">
        id : <?= $result->data->id ?><br>
        First Name : <?= $result->data->first_name ?><br>
        Last Name : <?= $result->data->last_name ?><br>
        Email : <?= $result->data->email ?><br>
<img src="<?= $result->data->avatar ?>" alt="">

                </div>
    <?php endif; ?>
              
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">POST Request</h5>
                <form id="postRequestForm" action="/post" method="post">
                    <div class="form-group">
                        <label for="postName">Name:</label>
                        <input type="text" class="form-control" id="postName" name="postName">
                    </div>
                    <div class="form-group">
                        <label for="postJob">Job:</label>
                        <input type="text" class="form-control" id="postJob" name="postJob">
                    </div>
                    <button type="submit" class="btn btn-primary">Create User</button>
                </form>
                <?php if ($type == 'post'): ?>
         <div id="getResponse">
        id : <?= $result->data->id ?><br>
       name: <?= $result->data->name ?><br>
       job : <?= $result->data->job ?><br>
                </div>
    <?php endif; ?>
              
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">PUT Request</h5>
                <form id="putRequestForm" action="/put" method="post">
                    <div class="form-group">
                        <label for="putUserId">User ID:</label>
                        <input type="number" class="form-control" id="putUserId" name="putUserId">
                    </div>
                    <div class="form-group">
                        <label for="putName">New Name:</label>
                        <input type="text" class="form-control" id="putName" name="putName">
                    </div>
                    <div class="form-group">
                        <label for="putJob">New Job:</label>
                        <input type="text" class="form-control" id="putJob" name="putJob">
                    </div>
                    <button type="submit" class="btn btn-primary">Update User</button>
                </form>
                <?php if ($type == 'put'): ?>
         <div id="getResponse">
        id : <?= $result->data->id ?><br>
       name: <?= $result->data->name ?><br>
       job : <?= $result->data->job ?><br>
                </div>
    <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">DELETE Request</h5>
                <form id="deleteRequestForm" action="/delete" method="post">
                    <div class="form-group">
                        <label for="deleteUserId">User ID:</label>
                        <input type="number" class="form-control" id="deleteUserId" name="deleteUserId">
                    </div>
                    <button type="submit" class="btn btn-danger">Delete User</button>
                </form>
                <?php if ($type == 'delete'): ?>
         <div id="getResponse">
        id : <?= $result->data->id ?><br>
       name: <?= $result->data->name ?><br>
       job : <?= $result->data->job ?><br>
                </div>
    <?php endif; ?>
            </div>
        </div>
    </div>





<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

</body>
</html>