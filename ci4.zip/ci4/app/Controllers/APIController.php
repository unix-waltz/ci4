<?php

namespace App\Controllers;

class APIController extends BaseController
{
    public function index()
    {
        $data['type'] = "";
        return view('index',$data);
    }
    public function get()
    {
        $userId = $this->request->getVar('getUserId');
        $url = "https://reqres.in/api/users/{$userId}";
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
    
        $data['result'] = json_decode($response);
        $data['type'] = 'get';
        return view('index', $data);
    }
    public function post()
{
    $postData = [
        'name' =>  $this->request->getVar('postName'),
        'job' =>  $this->request->getVar('postJob')
    ];
    $url = "https://reqres.in/api/users";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
   
    $data['result'] = json_decode($response);
    $data['type'] = 'post';
    return view('index', $data);
}
public function put()
{
    $userId = $this->request->getVar('putUserId');
    $newName = $this->request->getVar('putName');
    $newJob = $this->request->getVar('putJob');
    $putData = [
        'name' => $newName,
        'job' => $newJob
    ];
    $url = "https://reqres.in/api/users/{$userId}";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($putData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $data['result'] = json_decode($response);
    $data['type'] = 'put';
    return view('index', $data);
}


    public function delete()
    {
        $userId = $this->request->getVar('deleteUserId');
        $url = "https://reqres.in/api/users/{$userId}";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        $data['result'] = json_decode($response);
        $data['type'] = 'delete';
        return view('index', $data);
    }
}
