<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'APIController::index');
$routes->get('/get', 'APIController::get');
$routes->post('/post', 'APIController::post');
$routes->post('/put', 'APIController::put');
$routes->post('/delete', 'APIController::delete');
